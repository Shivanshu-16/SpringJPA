package com.pack.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pack.demo.model.Employee;
import com.pack.demo.service.EmployeeService;

@Controller
public class EmployeeController 
{
	@Autowired
	EmployeeService empService;
	
	@RequestMapping("/addEmp")
	public String addEmp (Model m)
	{
		m.addAttribute("empBean",new Employee());
		return "emp";
	}
	
	@RequestMapping("/empSave")
	public String saveEmp(@ModelAttribute("empBean") Employee e)
	{
		empService.addEmployee(e);
		return "success";
	}
}
